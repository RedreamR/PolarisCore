package age.of.civilizations2.jakowski.lukasz;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Json;

@SuppressWarnings("unused")
public class rfResearch
{
    public static final rfResearch INSTANCE = new rfResearch();
    private boolean isInsideMode = false;
    public static rfResearchConfigData configInstance = null;
    public final String WATERMARK = "RAINFALL RESEARCH 1.3.0";
    public final String CODENAME = "sparkle";

    public static void main(String[] args){
        Json json = new Json();
        System.out.println(json.prettyPrint(json.toJson(buildDefaultConfig())));
    }

    public static rfResearchConfigData buildDefaultConfig(){
        rfResearchConfigData data = new rfResearchConfigData();

        ResearchItemConfigData item = new ResearchItemConfigData();
        item.name = "POP_GROWTH";
        item.AddPerPoints = 0.75f;
        item.PointsMax = 50;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "ECONOMY_GROWTH";
        item.AddPerPoints = 0.75f;
        item.PointsMax = 50;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "INCOME_TAXATION";
        item.AddPerPoints = 0.2f;
        item.PointsMax = 50;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "INCOME_PRODUCTION";
        item.AddPerPoints = 0.2f;
        item.PointsMax = 50;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "ADMINISTRATION";
        item.AddPerPoints = 0.3f;
        item.PointsMax = 40;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "MILITARY_UPKEEP";
        item.AddPerPoints = 0.35f;
        item.PointsMax = 60;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "RESEARCH";
        item.AddPerPoints = 0.75f;
        item.PointsMax = 60;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "COLONIZATION";
        item.AddPerPoints =  1f;
        item.PointsMax = 40;
        data.researchItems.add(item);
        item = new ResearchItemConfigData();
        item.name = "TACTICS";
        item.AddPerPoints = 1f;
        item.PointsMax = 50;
        data.researchItems.add(item);
        data.enabledTechPointLimit = true;
        data.TechPointLimit_StagePercent = 0.1f;
        return data;
    }

    public static rfResearchConfigData loadConfig(){
        try{
            Gdx.app.log("AoC","rfResearch tryToLoadConfig");
            Json json = new Json();
            json.setElementType(rfResearchConfigData.class,"researchItems", ResearchItemConfigData.class);
            FileHandle fileHandle = Gdx.files.internal("Rainfall/rfResearch.json");
            return json.fromJson(rfResearchConfigData.class,fileHandle);
        }catch(Exception e){
            Gdx.app.log("AoC","rfResearch LOAD CONFIG FAIL!",e);
            rfResearchConfigData config = buildDefaultConfig();
            Gdx.app.log("AoC","rfResearch loadDefaultConfig");
            return config;
        }
    }

    public ResearchItemConfigData getResearchItemByName(String str){
        for (ResearchItemConfigData data : configInstance.researchItems){
            if(str.equals(data.name))return data;
        }
        ResearchItemConfigData data2 = new ResearchItemConfigData();
        data2.name = str;
        data2.AddPerPoints = 114514f;
        data2.PointsMax = 999999;
        return data2;
    }

    public static int getTacticsPoints(int civID){
        return CFG.game.getCiv(civID).civGameData.skills.POINTS_TACTICS;
    }
    
    public int getTechPointLimitBase(int CivID){
        return (CFG.game.getCiv(CivID).getTechnologyLevel_INT() - 1 ) / 40 + 1;
    }
    public int getMaxPoints(){
        return SkillsManager.MAX_POINTS_ADMINISTRATION+SkillsManager.MAX_POINTS_ECONOMY_GROWTH+SkillsManager.MAX_POINTS_ADMINISTRATION+SkillsManager.MAX_POINTS_POP_GROWTH+SkillsManager.MAX_POINTS_TACTICS+SkillsManager.MAX_POINTS_INCOME_PRODUCTION+SkillsManager.MAX_POINTS_RESEARCH+SkillsManager.MAX_POINTS_COLONIZATION+SkillsManager.MAX_POINTS_INCOME_TAXATION;
    }

    public boolean getIsInsideMode(){
        isInsideMode = Gdx.files.internal("Rainfall/SPARKLE").exists();
        if(isInsideMode){
            Gdx.app.log("AoC","rfSparkle enabled.");
        }
        return isInsideMode;
    }
}

class ResearchItemConfigData{
    public String name;
    public float AddPerPoints;
    public int PointsMax;

}

class rfResearchConfigData{
    public Array<ResearchItemConfigData> researchItems = new Array<>();
    public boolean enabledTechPointLimit; //是否启用科技点限制
    public float TechPointLimit_StagePercent;//每达到总科技点的 x% 解锁下一阶段的科技加点
}
