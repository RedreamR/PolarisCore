//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package age.of.civilizations2.jakowski.lukasz;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;
import java.util.List;

class Menu_InGame_Technology extends SliderMenu {
    protected int iCivID;
    protected long lTime = 0L;

    protected Menu_InGame_Technology() {
        List<MenuElement> menuElements = new ArrayList();
        int tempWidth = CFG.CIV_INFO_MENU_WIDTH * 2;
        int tY = CFG.PADDING;
        menuElements.add(new Button_Flag_JustFrame(CFG.PADDING, tY, true));
        int var10000 = tY + ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight();
        int tempMenuPosY = ImageManager.getImage(Images.top_left2).getHeight() + CFG.PADDING * 2 + CFG.BUTTON_HEIGHT * 3 / 5;
        this.initMenu(new SliderMenuTitle(CFG.langManager.get("TechnologyPoints"), CFG.BUTTON_HEIGHT * 3 / 5, true, true), CFG.GAME_WIDTH / 2 - tempWidth * 3 / 8, tempMenuPosY, tempWidth, ((MenuElement)menuElements.get(menuElements.size() - 1)).getPosY() + ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING + tempMenuPosY > CFG.GAME_HEIGHT - CFG.BUTTON_HEIGHT - CFG.PADDING * 2 ? Math.max(CFG.GAME_HEIGHT - CFG.BUTTON_HEIGHT - CFG.PADDING * 2 - tempMenuPosY, (CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 6) : ((MenuElement)menuElements.get(menuElements.size() - 1)).getPosY() + ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING, menuElements, false, true);
        this.updateLanguage();
    }

    protected Menu_InGame_Technology(int nCivID) {
        List<MenuElement> menuElements = new ArrayList();
        int tempWidth = CFG.CIV_INFO_MENU_WIDTH * 2;
        int tY = 0;
        this.iCivID = nCivID;
        menuElements.add(new Button_Technology(nCivID, 2, tY, CFG.BUTTON_WIDTH * 2) {
            protected int getWidth() {
                return Menu_InGame_Technology.this.getElementW() * 2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.population_growth, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Tech(rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").AddPerPoints, CFG.langManager.get("PopulationGrowthModifier"), Button_Diplomacy.iDiploWidth + CFG.PADDING, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0,rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").PointsMax, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_POP_GROWTH) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_TEXT_POPULATION.r, CFG.COLOR_TEXT_POPULATION.g, CFG.COLOR_TEXT_POPULATION.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 6, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("PopulationGrowthModifier") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").AddPerPoints+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_PopGrowth(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_POP_GROWTH);
            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.economy, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Tech(rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").AddPerPoints, CFG.langManager.get("EconomyGrowthModifier"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0,rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").PointsMax,  CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_ECONOMY_GROWTH) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_TEXT_ECONOMY.r, CFG.COLOR_TEXT_ECONOMY.g, CFG.COLOR_TEXT_ECONOMY.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 6, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("EconomyGrowthModifier") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").AddPerPoints+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_EcoGrowth(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_ECONOMY_GROWTH);
            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.top_gold, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Tech(SkillsManager.PER_POINT_INCOME_TAXATION, CFG.langManager.get("IncomeTaxation"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, SkillsManager.MAX_POINTS_INCOME_TAXATION, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_INCOME_TAXATION) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_INGAME_GOLD.r, CFG.COLOR_INGAME_GOLD.g, CFG.COLOR_INGAME_GOLD.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("IncomeTaxation") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+SkillsManager.PER_POINT_INCOME_TAXATION+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_IncomeTaxation(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_INCOME_TAXATION);
                Menu_InGame_Technology.this.rebuildBudgetView();
                Menu_InGame.updateOverBudget();
                if (CFG.viewsManager.getActiveViewID() == ViewsManager.VIEW_INCOME_MODE && CFG.menuManager.getVisible_InGame_View_Stats()) {
                    CFG.menuManager.setVisible_InGame_ViewIncome(true);
                }

            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.development, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Tech(SkillsManager.PER_POINT_INCOME_PRODUCTION, CFG.langManager.get("IncomeProduction"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, SkillsManager.MAX_POINTS_INCOME_PRODUCTION, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_INCOME_PRODUCTION) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_INGAME_GOLD_ACTIVE.r, CFG.COLOR_INGAME_GOLD_ACTIVE.g, CFG.COLOR_INGAME_GOLD_ACTIVE.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("IncomeProduction") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+SkillsManager.PER_POINT_INCOME_PRODUCTION+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_IncomeProduction(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_INCOME_PRODUCTION);
                Menu_InGame_Technology.this.rebuildBudgetView();
                Menu_InGame.updateOverBudget();
                if (CFG.viewsManager.getActiveViewID() == ViewsManager.VIEW_INCOME_MODE && CFG.menuManager.getVisible_InGame_View_Stats()) {
                    CFG.menuManager.setVisible_InGame_ViewIncome(true);
                }

            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.top_gold2, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Adm(SkillsManager.PER_POINT_ADMINISTRATION, CFG.langManager.get("Administration"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, SkillsManager.MAX_POINTS_ADMINISTRATION, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_ADMINISTRATION) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE_ACTTIVE.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE_ACTTIVE.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE_ACTTIVE.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Administration") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("-"+SkillsManager.PER_POINT_ADMINISTRATION+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_Administration(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_ADMINISTRATION);
                Menu_InGame_Technology.this.rebuildBudgetView();
                Menu_InGame.updateOverBudget();
                if (CFG.viewsManager.getActiveViewID() == ViewsManager.VIEW_INCOME_MODE && CFG.menuManager.getVisible_InGame_View_Stats()) {
                    CFG.menuManager.setVisible_InGame_ViewIncome(true);
                }

            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.diplo_army, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Adm(SkillsManager.PER_POINT_MILITARY_UPKEEP, CFG.langManager.get("MilitaryUpkeep"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, SkillsManager.MAX_POINTS_MILITARY_UPKEEP, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_MILITARY_UPKEEP) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_ARMY_TEXT.r, CFG.COLOR_ARMY_TEXT.g, CFG.COLOR_ARMY_TEXT.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("MilitaryUpkeep") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("-"+SkillsManager.PER_POINT_MILITARY_UPKEEP+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_MilitaryUpkeep(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_MILITARY_UPKEEP);
                Menu_InGame_Technology.this.rebuildBudgetView();
                Menu_InGame.updateOverBudget();
            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.provinces, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Adm(SkillsManager.PER_POINT_COLONIZATION, CFG.langManager.get("ColonizationCost"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, SkillsManager.MAX_POINTS_COLONIZATION, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_COLONIZATION) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_GRADIENT_TITLE_BLUE_LIGHT_ALLIANCE.r, CFG.COLOR_GRADIENT_TITLE_BLUE_LIGHT_ALLIANCE.g, CFG.COLOR_GRADIENT_TITLE_BLUE_LIGHT_ALLIANCE.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("ColonizationCost") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("-"+SkillsManager.PER_POINT_COLONIZATION+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_Colonization(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_COLONIZATION);
            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.research, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Tech(SkillsManager.PER_POINT_RESEARCH, CFG.langManager.get("Research"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, SkillsManager.MAX_POINTS_RESEARCH, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_RESEARCH) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_TEXT_RESEARCH.r, CFG.COLOR_TEXT_RESEARCH.g, CFG.COLOR_TEXT_RESEARCH.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Research") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+SkillsManager.PER_POINT_RESEARCH+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_Research(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_RESEARCH);
                Menu_InGame_Technology.this.rebuildBudgetView();
                Menu_InGame.updateOverBudget();
            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        //1
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        menuElements.add(new Button_Icon(Images.diplo_rivals, 0, tY));
        menuElements.add(new Slider_FlagAction_Clear_Tech(rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints, CFG.langManager.get("Tactics"), CFG.PADDING + Button_Diplomacy.iDiploWidth, tY, tempWidth - CFG.PADDING * 3 - CFG.BUTTON_WIDTH, CFG.TEXT_HEIGHT + CFG.PADDING * 6, 0, rfResearch.INSTANCE.getResearchItemByName("TACTICS").PointsMax, CFG.game.getCiv(this.iCivID).civGameData.skills.POINTS_TACTICS) {
            protected int getWidth() {
                return Math.max(Menu_InGame_Technology.this.getElementW() * 2 - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING * 4 - Button_Diplomacy.iDiploWidth, 0);
            }

            protected Color getColorLEFT() {
                return new Color(CFG.COLOR_TEXT_RESEARCH.r, CFG.COLOR_TEXT_RESEARCH.g, CFG.COLOR_TEXT_RESEARCH.b, 0.65F);
            }

            protected void actionElement(int iID) {
            }
        });
        menuElements.add(new Button_FlagActionSliderStyle("+", -1, tempWidth - CFG.BUTTON_WIDTH * 3 / 4 - CFG.PADDING, tY, CFG.BUTTON_WIDTH * 3 / 4, CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4, true) {
            protected int getPosX() {
                return Menu_InGame_Technology.this.getElementW() * 2 - this.getWidth() - CFG.PADDING;
            }

            protected void buildElementHover() {
                List<MenuElement_Hover_v2_Element2> nElements = new ArrayList();
                List<MenuElement_Hover_v2_Element_Type> nData = new ArrayList();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AddPoint"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                nData.add(new MenuElement_Hover_v2_Element_Type_Flag(Menu_InGame_Technology.this.iCivID, CFG.PADDING, 0));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AttackBonus") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                nData.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("DefenseBonus") + ": "));
                nData.add(new MenuElement_Hover_v2_Element_Type_Text("+"+rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints+"%", CFG.COLOR_TEXT_MODIFIER_POSITIVE));
                nElements.add(new MenuElement_Hover_v2_Element2(nData));
                nData.clear();
                this.menuElementHover = new MenuElement_Hover_v2(nElements);
            }

            protected void actionElement(int iID) {
                SkillsManager.add_Tactics(Menu_InGame_Technology.this.iCivID);
                Menu_InGame_Technology.this.getMenuElement(0).setMin(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.getPointsLeft(Menu_InGame_Technology.this.iCivID));
                Menu_InGame_Technology.this.getMenuElement(iID - 1).setCurrent(CFG.game.getCiv(Menu_InGame_Technology.this.iCivID).civGameData.skills.POINTS_TACTICS);
                Menu_InGame_Technology.this.rebuildBudgetView();
                Menu_InGame.updateOverBudget();
            }

            protected int getSFX() {
                return SoundsManager.SOUND_CLICK2;
            }
        });
        //2
        tY += ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING;
        tY += CFG.PADDING;
        menuElements.add(new Button_FlagActionSliderStyle(CFG.langManager.get("Close"), -1, CFG.PADDING, tY, CFG.BUTTON_WIDTH, true) {
            protected int getWidth() {
                return Menu_InGame_Technology.this.getElementW() * 2 - CFG.PADDING * 2;
            }
        });
        int tempMenuPosY = ImageManager.getImage(Images.top_left2).getHeight() + CFG.PADDING * 2 + CFG.BUTTON_HEIGHT * 3 / 5;
        this.initMenu(new SliderMenuTitle(CFG.langManager.get("TechnologyPoints"), CFG.BUTTON_HEIGHT * 3 / 5, true, true) {
            protected void draw(SpriteBatch oSB, int iTranslateX, int nPosX, int nPosY, int nWidth, boolean sliderMenuIsActive) {
                ImageManager.getImage(Images.dialog_title).draw2(oSB, nPosX - 2 + iTranslateX, nPosY - this.getHeight() - ImageManager.getImage(Images.dialog_title).getHeight(), nWidth + 4 - ImageManager.getImage(Images.dialog_title).getWidth(), this.getHeight());
                ImageManager.getImage(Images.dialog_title).draw2(oSB, nPosX + nWidth + 2 - ImageManager.getImage(Images.dialog_title).getWidth() + iTranslateX, nPosY - this.getHeight() - ImageManager.getImage(Images.dialog_title).getHeight(), ImageManager.getImage(Images.dialog_title).getWidth(), this.getHeight(), true, false);
                oSB.setColor(new Color((float)CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getR() / 255.0F, (float)CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getG() / 255.0F, (float)CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getB() / 255.0F, 0.165F));
                ImageManager.getImage(Images.line_32_off1).draw(oSB, nPosX + iTranslateX, nPosY - this.getHeight() + 2 - ImageManager.getImage(Images.line_32_off1).getHeight(), nWidth, this.getHeight() - 2, false, true);
                oSB.setColor(new Color((float)CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getR() / 255.0F, (float)CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getG() / 255.0F, (float)CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getB() / 255.0F, 0.375F));
                ImageManager.getImage(Images.gradient).draw(oSB, nPosX + iTranslateX, nPosY - this.getHeight() * 2 / 3 - ImageManager.getImage(Images.gradient).getHeight(), nWidth, this.getHeight() * 2 / 3, false, true);
                oSB.setColor(new Color(0.0F, 0.0F, 0.0F, 0.65F));
                ImageManager.getImage(Images.gradient).draw(oSB, nPosX + iTranslateX, nPosY - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight(), nWidth, CFG.PADDING, false, true);
                oSB.setColor(CFG.COLOR_NEW_GAME_EDGE_LINE);
                ImageManager.getImage(Images.pix255_255_255).draw(oSB, nPosX + iTranslateX, nPosY - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight(), nWidth, 1);
                oSB.setColor(new Color(0.0F, 0.0F, 0.0F, 0.55F));
                ImageManager.getImage(Images.line_32_off1).draw(oSB, nPosX + iTranslateX, nPosY - 2 - ImageManager.getImage(Images.line_32_off1).getHeight(), nWidth, 1);
                oSB.setColor(new Color(0.0F, 0.0F, 0.0F, 0.8F));
                ImageManager.getImage(Images.line_32_off1).draw(oSB, nPosX + iTranslateX, nPosY - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), nWidth, 1);
                oSB.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.45F));
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + iTranslateX, nPosY - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), nWidth / 2, 1);
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + nWidth - nWidth / 2 + iTranslateX, nPosY - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), nWidth / 2, 1, true, false);
                oSB.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.425F));
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + CFG.PADDING * 2 + iTranslateX, nPosY + 1 - this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight(), (int)(((float)(nWidth - CFG.PADDING * 6) - (float)this.getTextWidth() * 0.8F) / 2.0F), 1, true, false);
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + nWidth / 2 + CFG.PADDING + (int)((float)this.getTextWidth() * 0.8F / 2.0F) + iTranslateX, nPosY + 1 - this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight(), (int)(((float)(nWidth - CFG.PADDING * 6) - (float)this.getTextWidth() * 0.8F) / 2.0F), 1);
                oSB.setColor(new Color(0.0F, 0.0F, 0.0F, 0.325F));
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + CFG.PADDING * 2 + iTranslateX, nPosY + 2 - this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight(), (int)(((float)(nWidth - CFG.PADDING * 6) - (float)this.getTextWidth() * 0.8F) / 2.0F), 1, true, false);
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + nWidth / 2 + CFG.PADDING + (int)((float)this.getTextWidth() * 0.8F / 2.0F) + iTranslateX, nPosY + 2 - this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight(), (int)(((float)(nWidth - CFG.PADDING * 6) - (float)this.getTextWidth() * 0.8F) / 2.0F), 1);
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + CFG.PADDING * 2 + iTranslateX, nPosY - this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight(), (int)(((float)(nWidth - CFG.PADDING * 6) - (float)this.getTextWidth() * 0.8F) / 2.0F), 1, true, false);
                ImageManager.getImage(Images.slider_gradient).draw(oSB, nPosX + nWidth / 2 + CFG.PADDING + (int)((float)this.getTextWidth() * 0.8F / 2.0F) + iTranslateX, nPosY - this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight(), (int)(((float)(nWidth - CFG.PADDING * 6) - (float)this.getTextWidth() * 0.8F) / 2.0F), 1);
                oSB.setColor(Color.WHITE);
                CFG.fontMain.getData().setScale(0.8F);
                CFG.drawText(oSB, this.getText(), nPosX + (int)((float)nWidth - (float)this.getTextWidth() * 0.8F) / 2 + iTranslateX, 2 + nPosY - this.getHeight() + (int)((float)this.getHeight() - (float)this.getTextHeight() * 0.8F) / 2, Color.WHITE);
                CFG.fontMain.getData().setScale(1.0F);
            }
        }, CFG.GAME_WIDTH / 2 - tempWidth / 2, tempMenuPosY, tempWidth, ((MenuElement)menuElements.get(menuElements.size() - 1)).getPosY() + ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING + tempMenuPosY > CFG.GAME_HEIGHT - CFG.BUTTON_HEIGHT - CFG.PADDING * 2 ? Math.max(CFG.GAME_HEIGHT - CFG.BUTTON_HEIGHT - CFG.PADDING * 2 - tempMenuPosY, (CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 6) : ((MenuElement)menuElements.get(menuElements.size() - 1)).getPosY() + ((MenuElement)menuElements.get(menuElements.size() - 1)).getHeight() + CFG.PADDING, menuElements, true, true);
        this.updateLanguage();
        this.lTime = System.currentTimeMillis();

        for(int i = 0; i < this.getMenuElementsSize(); ++i) {
            this.getMenuElement(i).setCurrent(this.getMenuElement(i).getCurrent());
        }

    }

    protected void updateLanguage() {
        Menu_InGame_Technology.this.rebuildBudgetView();
    }

    protected void draw(SpriteBatch oSB, int iTranslateX, int iTranslateY, boolean sliderMenuIsActive) {
        if (this.lTime + 200L >= System.currentTimeMillis()) {
            Rectangle clipBounds = new Rectangle((float)(this.getPosX() - 2), (float)(CFG.GAME_HEIGHT - this.getPosY()), (float)(this.getWidth() + 4), (float)(-((int)((float)(this.getHeight() + CFG.PADDING) * ((float)(System.currentTimeMillis() - this.lTime) / 200.0F)))));
            oSB.flush();
            ScissorStack.pushScissors(clipBounds);
            oSB.setColor(Color.WHITE);
            ImageManager.getImage(Images.new_game_top_edge).draw2(oSB, this.getPosX() - 2 + iTranslateX, this.getPosY() - ImageManager.getImage(Images.new_game_top_edge).getHeight() + iTranslateY, this.getWidth() - ImageManager.getImage(Images.new_game_top_edge).getWidth() + 4, this.getHeight() + CFG.PADDING, false, true);
            ImageManager.getImage(Images.new_game_top_edge).draw2(oSB, this.getPosX() + 2 + this.getWidth() - ImageManager.getImage(Images.new_game_top_edge).getWidth() + iTranslateX, this.getPosY() - ImageManager.getImage(Images.new_game_top_edge).getHeight() + iTranslateY, ImageManager.getImage(Images.new_game_top_edge).getWidth(), this.getHeight() + CFG.PADDING, true, true);
            oSB.setColor(new Color(0.0F, 0.0F, 0.0F, 0.45F));
            ImageManager.getImage(Images.gradient).draw(oSB, this.getPosX() + 2 + iTranslateX, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + iTranslateY, this.getWidth() - 4, this.getHeight() / 4);
            ImageManager.getImage(Images.pix255_255_255).draw(oSB, this.getPosX() + 2 + iTranslateX, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + iTranslateY, this.getWidth() - 4, 1);
            oSB.setColor(Color.WHITE);
            this.drawMenu(oSB, iTranslateX, iTranslateY, sliderMenuIsActive);
            oSB.setColor(Color.WHITE);
            CFG.setRender_3(true);
            this.endClip(oSB, iTranslateX, iTranslateY, sliderMenuIsActive);
        } else {
            oSB.setColor(Color.WHITE);
            ImageManager.getImage(Images.new_game_top_edge).draw2(oSB, this.getPosX() - 2 + iTranslateX, this.getPosY() - ImageManager.getImage(Images.new_game_top_edge).getHeight() + iTranslateY, this.getWidth() - ImageManager.getImage(Images.new_game_top_edge).getWidth() + 4, this.getHeight() + CFG.PADDING, false, true);
            ImageManager.getImage(Images.new_game_top_edge).draw2(oSB, this.getPosX() + 2 + this.getWidth() - ImageManager.getImage(Images.new_game_top_edge).getWidth() + iTranslateX, this.getPosY() - ImageManager.getImage(Images.new_game_top_edge).getHeight() + iTranslateY, ImageManager.getImage(Images.new_game_top_edge).getWidth(), this.getHeight() + CFG.PADDING, true, true);
            oSB.setColor(new Color(0.0F, 0.0F, 0.0F, 0.45F));
            ImageManager.getImage(Images.gradient).draw(oSB, this.getPosX() + 2 + iTranslateX, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + iTranslateY, this.getWidth() - 4, this.getHeight() / 4);
            ImageManager.getImage(Images.pix255_255_255).draw(oSB, this.getPosX() + 2 + iTranslateX, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + iTranslateY, this.getWidth() - 4, 1);
            oSB.setColor(Color.WHITE);
            this.beginClip(oSB, iTranslateX, iTranslateY, sliderMenuIsActive);
            this.drawMenu(oSB, iTranslateX, iTranslateY, sliderMenuIsActive);
            oSB.setColor(Color.WHITE);
            this.endClip(oSB, iTranslateX, iTranslateY, sliderMenuIsActive);
        }

    }

    protected void drawScrollPos(SpriteBatch oSB, int iTranslateX, int iTranslateY, boolean sliderMenuIsActive) {
        if (sliderMenuIsActive) {
            super.drawScrollPos(oSB, iTranslateX, iTranslateY, sliderMenuIsActive);
        }

    }

    protected final void actionElement(int iID) {
        if (iID == this.getMenuElementsSize() - 1) {
            this.setVisible(false);
        } else {
            this.getMenuElement(iID).actionElement(iID);
        }
    }

    protected final int getW() {
        return this.getWidth() - 4;
    }

    protected final int getElementW() {
        return this.getW() / 2;
    }

    protected void setVisible(boolean visible) {
        super.setVisible(visible);
        if (!visible) {
            for(int i = 0; i < this.getMenuElementsSize(); ++i) {
                this.getMenuElement(i).setVisible(false);
            }
        }

    }

    protected void rebuildBudgetView() {
        if (CFG.menuManager.getVisible_InGame_Budget()) {
            CFG.menuManager.setVisible_InGame_Budget(true);
            Menu_InGame_FlagAction_Bot.lTime = 1L;
        } else if (CFG.menuManager.getVisible_InGame_FlagAction()) {
            CFG.menuManager.rebuildInGame_FlagActionLeft();
        } else {
            CFG.game_NextTurnUpdate.getBalance_UpdateBudget_Prepare(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
        }

        CFG.menuManager.setOrderOfTechPoints();
    }
}
