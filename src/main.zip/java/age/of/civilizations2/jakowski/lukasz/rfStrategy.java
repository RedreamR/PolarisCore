package age.of.civilizations2.jakowski.lukasz;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Json;

import java.util.ArrayList;


//Rainfall Strategy
@SuppressWarnings("unused")
public class rfStrategy{
    public static final rfStrategy INSTANCE = new rfStrategy();
    public rfStrategyConfigData configInstance;
    public static final boolean isPreviewVersion = false;
    public final String WATERMARK = "RAINFALL STRATEGY 3.6.0";
    public final String CODENAME = "seele";
    public rfStrategy(){
        configInstance = loadConfig();
    }
    
    //加载配置
    public rfStrategyConfigData loadConfig(){
        try{
            
           Gdx.app.log("AoC","rfStrategy tryToLoadConfig");
           Json json = new Json();
           FileHandle fileHandle = Gdx.files.internal("Rainfall/rfStrategy.json");
           return json.fromJson(rfStrategyConfigData.class,fileHandle);
        
        }catch(Exception e){
            Gdx.app.log("AoC","rfStrategy LOAD CONFIG FAIL!",e);
            rfStrategyConfigData config = new rfStrategyConfigData();
            config.isTacticsAddWarFieldWidth = true;
            config.addWarFieldWidthEachTactics = 1000;
            config.enabledTechBonus = true;
            config.enabledVassalRetreatToSuzerain = true;
            config.lossRate = 0.3f;
            config.techBonusMulBase = 18.0f;
            config.techBonusLimit = 18.0f;
            config.addWarFieldWidthEachProvince = 1000;
            config.baseWarFieldWidth = 5000;
            Gdx.app.log("AoC","rfStrategy loadDefaultConfig");
            return config;
        }
        
        
        
    }
    
    public String printConfig(){
        rfStrategyConfigData config = new rfStrategyConfigData();
        config.isTacticsAddWarFieldWidth = true;
        config.enabledTechBonus = true;
        config.enabledVassalRetreatToSuzerain = true;
        config.lossRate = 0.3f;
        config.techBonusMulBase = 18.0f;
        config.techBonusLimit = 18.0f;
        config.addWarFieldWidthEachProvince = 1000;
        config.baseWarFieldWidth = 5000;
        config.enabledRandomRetreat = true;
        Json json = new Json();
        return json.prettyPrint(json.toJson(config));
    }
    
    public final int getMoveUnitsFromProvinceSize(MoveUnits_TurnData turndata) {
        int i;
        boolean isExists;
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (i=0;i < turndata.getMoveUnitsSize();i++){
            isExists = false;
            for(Integer integer : arrayList){
                if (integer.equals(i)) {
                    isExists = true;
                    break;
                }
            }
            if(!isExists) arrayList.add(i);
        }
        Gdx.app.log("AoC","rfStrategy MUFPS "+arrayList.size());
        return arrayList.size();
    }
    
    protected int getWarFieldWidth(MoveUnits_TurnData turndata) {
        int result = 0;       
        
        if(configInstance.isTacticsAddWarFieldWidth){
            try {
                Gdx.app.log("AoC","rfSeele try to add WFW");
                Class<?> clz = Class.forName("age.of.civilizations2.jakowski.lukasz.rfResearch");
                result = (int) clz.getMethod("getTacticsPoints",int.class).invoke(null,turndata.getCivID(0));
                result = result * configInstance.addWarFieldWidthEachTactics;
                Gdx.app.log("AoC","rfSeele try to add WFW;WFW "+result);
            } catch (ClassNotFoundException e){
                configInstance.isTacticsAddWarFieldWidth = false;
            } catch (Exception e) {
                configInstance.isTacticsAddWarFieldWidth = false;
                Gdx.app.log("AoC","rfSeele failed to add WFW",e);
            }
        }
        Gdx.app.log("AoC","rfSeele try to add WFW2;WFW2 "+result);
        int moveUnitsFromProvinceSize = getMoveUnitsFromProvinceSize(turndata);
        int tempWFW = (int) ((configInstance.baseWarFieldWidth + (moveUnitsFromProvinceSize > 1 ? configInstance.addWarFieldWidthEachProvince * (moveUnitsFromProvinceSize - 1) : 0)) / (1.0f + CFG.terrainTypesManager.getMovementCost(CFG.game.getProvince(turndata.getMoveUnits(0).getToProvinceID()).getTerrainTypeID())));
        return tempWFW+result;
    }
    
    public void retreat(int civID,int provinceID,int armyNum){
        Civilization civ =  CFG.game.getCiv(civID);
        Province province = CFG.game.getProvince(provinceID);
        Gdx.app.log("AoC","rfStrategy retreat1 name "+ province.getName()+" id "+province.getProvinceID()+" size "+province.getNeighboringProvincesSize());
        for(int i=1;i < province.getNeighboringProvincesSize();i++){
            int i2 = i-1;
            Province province_n = CFG.game.getProvince(province.getNeighboringProvinces(i2));
            Gdx.app.log("AoC","rfStrategy retreat name "+ province_n.getName()+" id "+province_n.getProvinceID());
            if(province_n.getSeaProvince()) {
                continue;
            }
            if(province_n.getCivID() == civ.getCivID() || CFG.game.getCivsAreAllied(civID, province_n.getCivID()) || (configInstance.enabledVassalRetreatToSuzerain && CFG.game.getCiv(civID).getPuppetOfCivID() == province_n.getCivID()) || CFG.game.getCiv(province_n.getCivID()).getPuppetOfCivID() == civID || CFG.game.getMilitaryAccess(province_n.getCivID(),civ.getCivID()) > 0){
                province_n.updateArmy(civ.getCivID(),province_n.getArmyCivID(civ.getCivID())+armyNum);
                Gdx.app.log("AoC","rfStrategy suc retreat name "+ province_n.getName()+" id "+province_n.getProvinceID());
                return;
            }
            
        }
        
    }
    protected final boolean isEnabledTechBonus(){
        return configInstance.enabledTechBonus;
    }
    protected final float getAttackersBonusFromTechnology2(int nCivID) {
        if(isEnabledTechBonus()){
            return Math.min(CFG.game.getCiv(nCivID).getTechnologyLevel() * configInstance.techBonusMulBase, configInstance.techBonusLimit);
        }
        return 0f;
    }
    protected final float getDefenseBonusFromTechnology2(int nCivID) {
        if (nCivID > 0 && isEnabledTechBonus()) {
            return Math.min(CFG.game.getCiv(nCivID).getTechnologyLevel() * configInstance.techBonusMulBase * 1.75f, configInstance.techBonusLimit*1.75f);
        }
        return 0.0f;
    }
}

class rfStrategyConfigData{
    public boolean isTacticsAddWarFieldWidth; //Rainfall Research的Tactics点数是否增加战宽
    public int addWarFieldWidthEachTactics; //Rainfall Research每一Tactics点数增加多少战宽（当"isTacticsAddWarFieldWidth"为false时，此值无效。）
    public float lossRate; //损失率
    public boolean enabledTechBonus; //是否启用科技对战斗的加成
    public boolean enabledVassalRetreatToSuzerain; //是否允许附庸国军队撤离到宗主国领土
    public int baseWarFieldWidth;//基础战宽
    public int addWarFieldWidthEachProvince; //每多一路进攻增加的战宽
    public float techBonusLimit; //限制科技对战斗的加成。（守方在该数值上×1.75。）
    public float techBonusMulBase; //科技对战斗加成的倍率。
    public boolean enabledRandomRetreat; //允许在全灭时随机撤退0-3人。
}
