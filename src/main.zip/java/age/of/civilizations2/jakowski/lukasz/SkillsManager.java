// Decompiled with: Procyon 0.5.36
// Class Version: 6
package age.of.civilizations2.jakowski.lukasz;

import com.badlogic.gdx.Gdx;

import java.util.Random;

class SkillsManager {
    private static final Random rdm = new Random();
    protected static int MAX_POINTS_POP_GROWTH = rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").PointsMax;
    protected static float PER_POINT_POP_GROWTH = rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").AddPerPoints;
    protected static int MAX_POINTS_ECONOMY_GROWTH = rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").PointsMax;
    protected static float PER_POINT_ECONOMY_GROWTH = rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").AddPerPoints;
    protected static int MAX_POINTS_INCOME_TAXATION = rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").PointsMax;
    protected static float PER_POINT_INCOME_TAXATION = rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").AddPerPoints;
    protected static int MAX_POINTS_INCOME_PRODUCTION = rfResearch.INSTANCE.getResearchItemByName("INCOME_PRODUCTION").PointsMax;
    protected static float PER_POINT_INCOME_PRODUCTION = rfResearch.INSTANCE.getResearchItemByName("INCOME_PRODUCTION").AddPerPoints;
    protected static int MAX_POINTS_ADMINISTRATION = rfResearch.INSTANCE.getResearchItemByName("ADMINISTRATION").PointsMax;
    protected static float PER_POINT_ADMINISTRATION = rfResearch.INSTANCE.getResearchItemByName("ADMINISTRATION").AddPerPoints;
    protected static int MAX_POINTS_MILITARY_UPKEEP = rfResearch.INSTANCE.getResearchItemByName("MILITARY_UPKEEP").PointsMax;
    protected static float PER_POINT_MILITARY_UPKEEP = rfResearch.INSTANCE.getResearchItemByName("MILITARY_UPKEEP").AddPerPoints;
    protected static int MAX_POINTS_RESEARCH = rfResearch.INSTANCE.getResearchItemByName("RESEARCH").PointsMax;
    protected static float PER_POINT_RESEARCH = rfResearch.INSTANCE.getResearchItemByName("RESEARCH").AddPerPoints;
    protected static int MAX_POINTS_COLONIZATION = rfResearch.INSTANCE.getResearchItemByName("COLONIZATION").PointsMax;
    protected static float PER_POINT_COLONIZATION = rfResearch.INSTANCE.getResearchItemByName("COLONIZATION").AddPerPoints;
    //Rainfall Strategy 军事策略
    protected static int MAX_POINTS_TACTICS = rfResearch.INSTANCE.getResearchItemByName("TACTICS").PointsMax;
    //protected static final int MAX_POINTS_TACTICS = 50;
    protected static float PER_POINT_TACTICS = rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints;

    SkillsManager() {
    }
    
    public static final boolean canAdd_techPointLimit(int nCivID,int maxPoints,int nowPoints){
        double myPoints = CFG.game.getCiv(nCivID).getTechnologyLevel_INT();
        double totalMaxPoints = rfResearch.INSTANCE.getMaxPoints();
        myPoints = Math.min(myPoints,totalMaxPoints);
        int stage = (int) (Math.ceil((myPoints/totalMaxPoints)/rfResearch.configInstance.TechPointLimit_StagePercent));
        Gdx.app.log("AoC","tMP "+totalMaxPoints+" stage "+stage+" realPoint "+Math.floor(maxPoints * stage * 0.1f));
        return !(Math.floor(maxPoints * stage * 0.1f) < nowPoints+1);
    }
    
    protected static final boolean canAdd_PopGrowth(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_POP_GROWTH < MAX_POINTS_POP_GROWTH;
    }

    protected static final void add_PopGrowth(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").PointsMax,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_POP_GROWTH)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_PopGrowth -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_POP_GROWTH * rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").AddPerPoints / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_POP_GROWTH = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_POP_GROWTH + 1, rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").PointsMax);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_PopGrowth += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_POP_GROWTH * rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").AddPerPoints / 100.0F;
        }
    }

    protected static final boolean canAdd_EcoGrowth(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ECONOMY_GROWTH < rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").PointsMax;
    }

    protected static final void add_EcoGrowth(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").PointsMax,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ECONOMY_GROWTH)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_EconomyGrowth -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ECONOMY_GROWTH * rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").AddPerPoints / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ECONOMY_GROWTH = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ECONOMY_GROWTH + 1, rfResearch.INSTANCE.getResearchItemByName("POP_GROWTH").PointsMax);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_EconomyGrowth += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ECONOMY_GROWTH * rfResearch.INSTANCE.getResearchItemByName("ECONOMY_GROWTH").AddPerPoints / 100.0F;
        }
    }

    protected static final boolean canAdd_IncomeTaxation(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_TAXATION < rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").PointsMax;
    }

    protected static final void add_IncomeTaxation(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").PointsMax,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_TAXATION)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_IncomeTaxation -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_TAXATION * rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").AddPerPoints / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_TAXATION = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_TAXATION + 1, rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").PointsMax);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_IncomeTaxation += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_TAXATION * rfResearch.INSTANCE.getResearchItemByName("INCOME_TAXATION").AddPerPoints / 100.0F;
        }
    }

    protected static final boolean canAdd_IncomeProduction(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_PRODUCTION < MAX_POINTS_INCOME_PRODUCTION;
    }

    protected static final void add_IncomeProduction(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,MAX_POINTS_INCOME_PRODUCTION,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_PRODUCTION)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_IncomeProduction -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_PRODUCTION * PER_POINT_INCOME_PRODUCTION / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_PRODUCTION = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_PRODUCTION + 1, MAX_POINTS_INCOME_PRODUCTION);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_IncomeProduction += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_INCOME_PRODUCTION * PER_POINT_INCOME_PRODUCTION / 100.0F;
        }
    }

    protected static final boolean canAdd_Administration(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ADMINISTRATION < MAX_POINTS_ADMINISTRATION;
    }

    protected static final void add_Administration(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,MAX_POINTS_ADMINISTRATION,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ADMINISTRATION)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_Administration += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ADMINISTRATION * PER_POINT_ADMINISTRATION / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ADMINISTRATION = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ADMINISTRATION + 1, MAX_POINTS_ADMINISTRATION);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_Administration -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_ADMINISTRATION * PER_POINT_ADMINISTRATION / 100.0F;
        }
    }

    protected static final boolean canAdd_MilitaryUpkeep(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_MILITARY_UPKEEP < MAX_POINTS_MILITARY_UPKEEP;
    }

    protected static final void add_MilitaryUpkeep(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,MAX_POINTS_MILITARY_UPKEEP,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_MILITARY_UPKEEP)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_MilitaryUpkeep += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_MILITARY_UPKEEP * PER_POINT_MILITARY_UPKEEP / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_MILITARY_UPKEEP = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_MILITARY_UPKEEP + 1, MAX_POINTS_MILITARY_UPKEEP);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_MilitaryUpkeep -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_MILITARY_UPKEEP * PER_POINT_MILITARY_UPKEEP / 100.0F;
            if(rdm.nextBoolean() && rfResearch.INSTANCE.getIsInsideMode()){
                Gdx.app.log("AoC","rfSparkle try to add tactics!");
                add_Tactics(nCivID);
            }
        }
    }

    protected static final boolean canAdd_Research(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_RESEARCH < MAX_POINTS_RESEARCH;
    }

    protected static final void add_Research(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,MAX_POINTS_RESEARCH,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_RESEARCH)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_Research -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_RESEARCH * PER_POINT_RESEARCH / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_RESEARCH = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_RESEARCH + 1, MAX_POINTS_RESEARCH);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_Research += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_RESEARCH * PER_POINT_RESEARCH / 100.0F;
        }
    }

    protected static final boolean canAdd_Colonization(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_COLONIZATION < MAX_POINTS_COLONIZATION;
    }

    protected static final void add_Colonization(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,MAX_POINTS_COLONIZATION,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_COLONIZATION)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_ColonizationCost -= (float) CFG.game.getCiv(nCivID).civGameData.skills.POINTS_COLONIZATION * PER_POINT_COLONIZATION / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_COLONIZATION = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_COLONIZATION + 1, MAX_POINTS_COLONIZATION);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_ColonizationCost += (float) CFG.game.getCiv(nCivID).civGameData.skills.POINTS_COLONIZATION * PER_POINT_COLONIZATION / 100.0F;
        }
    }
    protected static final boolean canAdd_Tactics(int nCivID) {
        return CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS < MAX_POINTS_TACTICS;
    }

    protected static final void add_Tactics(int nCivID) {
        if (CFG.game.getCiv(nCivID).civGameData.skills.getPointsLeft(nCivID) > 0 && canAdd_techPointLimit(nCivID,rfResearch.INSTANCE.getResearchItemByName("TACTICS").PointsMax,CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS)) {
            Save_Civ_GameData var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_AttackBonus -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS * rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints / 100.0F;
            var10000.fModifier_DefenseBonus -= (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS * rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints / 100.0F;
            CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS = Math.min(CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS + 1, rfResearch.INSTANCE.getResearchItemByName("TACTICS").PointsMax);
            var10000 = CFG.game.getCiv(nCivID).civGameData;
            var10000.fModifier_AttackBonus += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS * rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints / 100.0F;
            var10000.fModifier_DefenseBonus += (float)CFG.game.getCiv(nCivID).civGameData.skills.POINTS_TACTICS * rfResearch.INSTANCE.getResearchItemByName("TACTICS").AddPerPoints / 100.0F;
        }
    }
}
