package age.of.civilizations2.jakowski.lukasz;

public class rfStrategy_Extra_Tactics {
    public static final String VERSION = "V1";
    public static final String ID = "RAINFALL STRATEGY EXTRA TACTICS";
}
